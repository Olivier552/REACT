import React from 'react'
import './unauth.css'

const Notfound = () => {
    return (
      <div className='unauth__home'>
        <h1 className='unauth__header'>404</h1>
        <h3 className='unauth__h4'>Page Not found!</h3>
        
        
      </div>
  )
}

export default Notfound
