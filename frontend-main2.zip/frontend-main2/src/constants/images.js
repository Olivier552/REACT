import aprt from "../assets/aprt.jpg";
import c1 from "../assets/c1.jpg";
import c2 from "../assets/c2.jpg";
import c3 from "../assets/c3.jpg";
import c4 from "../assets/c4.jpg";
import f1 from "../assets/f1.jpg";
import f2 from "../assets/f2.jpg";
import f3 from "../assets/f3.jpg";
import fm from "../assets/fm.jpg";
import kgl from "../assets/kgl.jpg";
import off from "../assets/off.jpg";
import logo from "../assets/logo.jpg";
import office from "../assets/office.jpg";
import log from "../assets/login.png";
import home from "../assets/home.jpg";
const imgs = {
  aprt,
  c1,
  c2,
  c3,
  c4,
  f1,
  f2,
  f3,
  fm,
  kgl,
  off,
  logo,
  office,
  home,
  log,
};
export default imgs;
